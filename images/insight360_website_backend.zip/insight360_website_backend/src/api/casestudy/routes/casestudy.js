'use strict';

/**
 * casestudy router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::casestudy.casestudy');
