'use strict';

/**
 * employees-testimony router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::employees-testimony.employees-testimony');
