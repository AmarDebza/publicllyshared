'use strict';

/**
 * employees-testimony service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::employees-testimony.employees-testimony');
