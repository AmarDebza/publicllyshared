'use strict';

/**
 * employees-testimony controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::employees-testimony.employees-testimony');
