'use strict';

/**
 * section controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::section.section');
