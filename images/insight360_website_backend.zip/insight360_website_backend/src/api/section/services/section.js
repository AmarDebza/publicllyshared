'use strict';

/**
 * section service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::section.section');
