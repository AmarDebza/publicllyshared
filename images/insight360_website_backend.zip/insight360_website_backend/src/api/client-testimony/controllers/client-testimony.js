'use strict';

/**
 * client-testimony controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::client-testimony.client-testimony');
