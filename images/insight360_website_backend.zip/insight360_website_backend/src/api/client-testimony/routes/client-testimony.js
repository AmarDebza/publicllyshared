'use strict';

/**
 * client-testimony router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::client-testimony.client-testimony');
