'use strict';

/**
 * client-testimony service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::client-testimony.client-testimony');
