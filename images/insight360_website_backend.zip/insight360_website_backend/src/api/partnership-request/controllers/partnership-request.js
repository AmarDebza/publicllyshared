'use strict';

/**
 * partnership-request controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::partnership-request.partnership-request');
