'use strict';

/**
 * partnership-request router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::partnership-request.partnership-request');
