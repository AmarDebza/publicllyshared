'use strict';

/**
 * engagment controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::engagment.engagment');
