'use strict';

/**
 * roadmap-step router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::roadmap-step.roadmap-step');
