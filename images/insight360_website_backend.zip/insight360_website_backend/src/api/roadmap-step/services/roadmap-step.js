'use strict';

/**
 * roadmap-step service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::roadmap-step.roadmap-step');
