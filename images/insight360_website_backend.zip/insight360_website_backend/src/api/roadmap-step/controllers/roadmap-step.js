'use strict';

/**
 * roadmap-step controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::roadmap-step.roadmap-step');
