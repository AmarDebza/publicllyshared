'use strict';

/**
 * sector controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::sector.sector');
