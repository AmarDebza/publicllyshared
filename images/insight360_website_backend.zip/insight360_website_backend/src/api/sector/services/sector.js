'use strict';

/**
 * sector service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::sector.sector');
