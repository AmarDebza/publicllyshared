'use strict';

/**
 * smpost controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::smpost.smpost');
