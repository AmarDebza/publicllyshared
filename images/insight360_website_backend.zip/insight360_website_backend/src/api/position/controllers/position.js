'use strict';

/**
 * position controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::position.position');
