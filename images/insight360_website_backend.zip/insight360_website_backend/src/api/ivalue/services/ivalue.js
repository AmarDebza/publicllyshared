'use strict';

/**
 * ivalue service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::ivalue.ivalue');
