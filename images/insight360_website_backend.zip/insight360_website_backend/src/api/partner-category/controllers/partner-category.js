'use strict';

/**
 * partner-category controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::partner-category.partner-category');
