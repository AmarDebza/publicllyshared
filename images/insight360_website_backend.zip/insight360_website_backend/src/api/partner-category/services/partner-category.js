'use strict';

/**
 * partner-category service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::partner-category.partner-category');
