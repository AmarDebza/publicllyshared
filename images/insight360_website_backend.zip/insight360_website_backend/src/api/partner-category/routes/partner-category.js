'use strict';

/**
 * partner-category router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::partner-category.partner-category');
