'use strict';

/**
 * inumber controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::inumber.inumber');
