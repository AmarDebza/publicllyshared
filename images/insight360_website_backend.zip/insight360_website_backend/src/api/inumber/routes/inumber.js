'use strict';

/**
 * inumber router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::inumber.inumber');
