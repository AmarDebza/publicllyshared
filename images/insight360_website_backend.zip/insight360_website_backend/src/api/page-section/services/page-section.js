'use strict';

/**
 * page-section service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::page-section.page-section');
