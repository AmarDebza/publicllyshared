'use strict';

/**
 * milestones-stat service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::milestones-stat.milestones-stat');
