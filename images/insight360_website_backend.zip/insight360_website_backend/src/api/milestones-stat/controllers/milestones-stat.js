'use strict';

/**
 * milestones-stat controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::milestones-stat.milestones-stat');
