'use strict';

/**
 * roadmap service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::roadmap.roadmap');
