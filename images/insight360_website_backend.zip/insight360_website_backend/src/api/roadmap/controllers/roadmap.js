'use strict';

/**
 * roadmap controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::roadmap.roadmap');
